# -*- coding: utf-8 -*-
"""Simkl account sync for Dex Hub (v4.1.0).

Mirrors the trakt.py architecture: device-PIN auth, watched-history sync at
playback end, and the user's Simkl lists (watching / plan-to-watch / completed
/ on-hold / dropped) exposed as browsable catalogs.

Simkl API notes (encoded from Simkl's public apiary docs — endpoints marked
[VERIFY-LIVE] should be confirmed against a live account on first run):
  * Base: https://api.simkl.com
  * Device auth:  GET /oauth/pin?client_id=X
                  -> {user_code, verification_url, expires_in, interval}
                  poll GET /oauth/pin/{user_code}?client_id=X
                  -> {"result":"KO"} until {"result":"OK","access_token":...}
  * Authed calls: headers  Authorization: Bearer <token>
                            simkl-api-key: <client_id>
  * Lists:   GET /sync/all-items/{movies|shows|anime}/{status}?extended=full
  * History: POST /sync/history  {"movies":[{"ids":{...}}],
                                  "shows":[{"ids":{...},"seasons":[
                                      {"number":S,"episodes":[{"number":E}]}]}]}

Unlike Trakt, Simkl has no start/pause scrobble stream — the documented sync
model is "mark watched when done", which is exactly what SimklReporter in
companion.py calls into here at playback end.
"""
import json
import re
import os
import time
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui

from .dexhub.common import profile_path
from . import playback_store
from .i18n import tr

try:
    from .settings_cache import cached_addon as _dh_cached_addon
except Exception:
    try:
        from settings_cache import cached_addon as _dh_cached_addon
    except Exception:
        _dh_cached_addon = None
ADDON = _dh_cached_addon() if _dh_cached_addon else xbmcaddon.Addon()

API = 'https://api.simkl.com'
TOKEN_PATH = os.path.join(profile_path(), 'simkl_token.json')
# Dex Hub's registered Simkl app (simkl.com/settings/developer, redirect
# urn:ietf:wg:oauth:2.0:oob) — same pattern as trakt.DEFAULT_CLIENT_ID.
# The client id is public by design (it identifies the app, it grants
# nothing); the PIN flow never needs the client secret, which is NOT
# embedded. The hidden setting `simkl_client_id` still overrides this.
DEFAULT_CLIENT_ID = '7c5c3e3c74fa28dd639ca8b09da8f5e48d46ee7c3ea86d284c56bee4a0a09643'
PIN_URL_FALLBACK = 'https://simkl.com/pin'

_PUBLIC_CACHE = {}
_PUBLIC_CACHE_TTL = 300
# One history POST per video per Kodi session — a stop at 96% followed by the
# natural "ended" event must not write the same episode twice.
_MARKED_THIS_SESSION = set()

# status keys per Simkl kind. Movies have no "watching"/"hold" shelf.
STATUSES_SHOWS = ('watching', 'plantowatch', 'hold', 'completed', 'dropped')
STATUSES_MOVIES = ('plantowatch', 'completed', 'dropped')
KINDS = ('movies', 'shows', 'anime')


def _setting(key, default=''):
    try:
        return ADDON.getSetting(key) or default
    except Exception:
        return default


def enabled():
    return (_setting('enable_simkl', 'true') or 'true').lower() == 'true'


def client_id():
    return (_setting('simkl_client_id', '').strip() or DEFAULT_CLIENT_ID).strip()


def credentials_configured():
    return bool(client_id())


def mark_watched_enabled():
    return (_setting('simkl_mark_watched', 'true') or 'true').lower() == 'true'


def watched_threshold_percent():
    try:
        value = float(_setting('simkl_watched_threshold', '85') or 85)
    except Exception:
        value = 85.0
    return max(50.0, min(99.0, value))


def ensure_enabled():
    try:
        if not enabled():
            ADDON.setSetting('enable_simkl', 'true')
    except Exception:
        pass


def _read_json(path, default):
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            return json.load(handle)
    except Exception:
        return default


def _write_json(path, value):
    try:
        with open(path, 'w', encoding='utf-8') as handle:
            json.dump(value, handle)
        return True
    except Exception:
        return False


def token_data():
    return _read_json(TOKEN_PATH, {})


def save_token(data):
    return _write_json(TOKEN_PATH, data or {})


def clear_token():
    try:
        if os.path.exists(TOKEN_PATH):
            os.remove(TOKEN_PATH)
    except Exception:
        pass


def authorized():
    return bool((token_data() or {}).get('access_token'))


def authorization_status():
    if authorized():
        return 'connected'
    return 'ready' if credentials_configured() else 'needs_api'


def _headers(auth=False):
    headers = {
        'Content-Type': 'application/json',
        'User-Agent': 'DexHub/%s (Kodi)' % (ADDON.getAddonInfo('version') or '4.1.0'),
        'simkl-api-key': client_id(),
    }
    if auth:
        token = (token_data() or {}).get('access_token') or ''
        if not token:
            raise RuntimeError(tr('حساب Simkl غير مرتبط'))
        headers['Authorization'] = 'Bearer %s' % token
    return headers


def _request(path, payload=None, method='GET', auth=False, timeout=20):
    url = API + path
    data = json.dumps(payload).encode('utf-8') if payload is not None else None
    req = urllib.request.Request(url, data=data, headers=_headers(auth=auth), method=method)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        body = resp.read().decode('utf-8', 'ignore')
        return json.loads(body) if body else {}


def _cached_request(path, auth=True, timeout=20):
    now = time.time()
    hit = _PUBLIC_CACHE.get(path)
    if hit and (now - hit[0]) <= _PUBLIC_CACHE_TTL:
        return hit[1]
    data = _request(path, method='GET', auth=auth, timeout=timeout)
    _PUBLIC_CACHE[path] = (now, data)
    return data


def invalidate_cache(prefix=''):
    for key in list(_PUBLIC_CACHE.keys()):
        if not prefix or key.startswith(prefix):
            _PUBLIC_CACHE.pop(key, None)


def _build_pin_message(verify_url, user_code, remaining=None):
    """Single-string message compatible with Kodi 20+ dialogs (trakt pattern)."""
    lines = [
        '[B]١) افتح الرابط:[/B]',
        '[COLOR orange]%s[/COLOR]' % verify_url,
        '',
        '[B]٢) أدخل الرمز:[/B]',
        '[COLOR yellow][B]   %s   [/B][/COLOR]' % user_code,
    ]
    if remaining is not None:
        lines.append('')
        lines.append(tr('المتبقي: %ss') % int(remaining))
    return '\n'.join(lines)


def device_auth():
    ensure_enabled()
    if not credentials_configured():
        raise RuntimeError(tr('أدخل Simkl Client ID في الإعدادات أولاً (من simkl.com/settings/developer)'))

    # Step 1: request a user code.
    try:
        code = _request('/oauth/pin?client_id=%s' % urllib.parse.quote(client_id()), method='GET', auth=False)
    except urllib.error.HTTPError as exc:
        try:
            body = exc.read().decode('utf-8', 'ignore')
        except Exception:
            body = ''
        raise RuntimeError(tr('فشل طلب رمز Simkl (%s): %s') % (exc.code, body[:200]))
    except Exception as exc:
        raise RuntimeError(tr('فشل الاتصال بـ Simkl: %s') % exc)

    user_code = str((code or {}).get('user_code') or '').strip()
    verify = str((code or {}).get('verification_url') or PIN_URL_FALLBACK)
    interval = max(5, int((code or {}).get('interval') or 5))
    expires_in = max(60, int((code or {}).get('expires_in') or 900))
    if not user_code:
        raise RuntimeError(tr('لم يرجع Simkl رمز ربط صالح'))

    # Step 2: show the PIN (dialog + sticky notification so it is never lost).
    try:
        xbmcgui.Dialog().ok(tr('Dex Hub • ربط Simkl'), tr(_build_pin_message(verify, user_code)))
    except Exception as exc:
        xbmc.log('[DexHub] simkl Dialog.ok fallback: %s' % exc, xbmc.LOGWARNING)
    xbmc.executebuiltin('Notification(Dex Hub,Simkl code: %s,10000)' % user_code)

    # Step 3: poll until the user approves on simkl.com/pin.
    dlg = xbmcgui.DialogProgress()
    dlg.create(tr('Dex Hub • ربط Simkl'), tr(_build_pin_message(verify, user_code, remaining=expires_in)))
    poll_path = '/oauth/pin/%s?client_id=%s' % (urllib.parse.quote(user_code), urllib.parse.quote(client_id()))
    start = time.time()
    try:
        while not dlg.iscanceled() and (time.time() - start) < expires_in:
            remaining = int(expires_in - (time.time() - start))
            pct = int(max(0, min(100, ((time.time() - start) / float(expires_in)) * 100)))
            dlg.update(pct, tr(_build_pin_message(verify, user_code, remaining=remaining)))
            try:
                token = _request(poll_path, method='GET', auth=False)
                if isinstance(token, dict) and token.get('access_token'):
                    save_token({'access_token': token.get('access_token'), 'created_at': int(time.time())})
                    dlg.close()
                    xbmcgui.Dialog().notification('Dex Hub', tr('تم ربط Simkl بنجاح'), xbmcgui.NOTIFICATION_INFO, 3000)
                    invalidate_cache()
                    return True
                # {"result":"KO"} → pending; keep polling quietly.
            except urllib.error.HTTPError as exc:
                if exc.code == 429:
                    interval = max(interval, 5) * 2
                elif exc.code in (400, 404):
                    pass  # pending / not-yet-entered — keep polling
                else:
                    xbmc.log('[DexHub] simkl poll http %s' % exc.code, xbmc.LOGWARNING)
            except Exception as exc:
                # Transient network hiccup — log and keep polling rather than die.
                xbmc.log('[DexHub] simkl poll transient error: %s' % exc, xbmc.LOGWARNING)
            xbmc.sleep(interval * 1000)
    finally:
        try:
            dlg.close()
        except Exception:
            pass
    return False


def logout():
    clear_token()
    invalidate_cache()
    _MARKED_THIS_SESSION.clear()
    return True


# ─── ids / payload helpers ──────────────────────────────────────────────────

def _ids_from_ctx(ctx):
    ids = {}
    imdb = str((ctx or {}).get('imdb_id') or '').strip()
    tmdb = str((ctx or {}).get('tmdb_id') or '').strip()
    tvdb = str((ctx or {}).get('tvdb_id') or '').strip()
    if imdb:
        ids['imdb'] = imdb if imdb.startswith('tt') else 'tt%s' % imdb
    if tmdb:
        ids['tmdb'] = tmdb
    if tvdb:
        ids['tvdb'] = tvdb
    return ids


def history_payload(ctx):
    """Build the POST /sync/history body for a playback ctx (movie or episode)."""
    ids = _ids_from_ctx(ctx)
    if not ids:
        return None
    media_type = str((ctx or {}).get('media_type') or 'movie').lower()
    if media_type in ('series', 'show', 'tv', 'anime', 'episode'):
        try:
            season = int(ctx.get('season'))
            episode = int(ctx.get('episode'))
        except Exception:
            return None
        if season <= 0 and episode <= 0:
            return None
        return {'shows': [{
            'title': ctx.get('show_title') or ctx.get('title') or '',
            'ids': ids,
            'seasons': [{'number': season, 'episodes': [{'number': episode}]}],
        }]}
    return {'movies': [{'title': ctx.get('title') or '', 'ids': ids}]}


def _session_key(ctx):
    base = str((ctx or {}).get('video_id') or (ctx or {}).get('canonical_id') or '')
    return base or json.dumps(_ids_from_ctx(ctx), sort_keys=True)


def should_mark_watched(position_ms, duration_ms, threshold=None):
    """Pure decision helper (unit-tested): watched iff progress ≥ threshold."""
    try:
        pos = float(position_ms or 0)
        dur = float(duration_ms or 0)
    except Exception:
        return False
    if dur <= 0:
        # No duration: only the explicit "ended" event (position 0 sentinel
        # from companion.ended when the player closed naturally) counts.
        return pos <= 0
    pct = (pos / dur) * 100.0
    return pct >= float(threshold if threshold is not None else watched_threshold_percent())


def mark_watched_from_ctx(ctx, position_ms=0, force=False):
    """Called by SimklReporter at stop/ended. POSTs /sync/history once per item.

    Returns True when a history write happened, False when skipped (below
    threshold, missing ids, disabled, or already written this session).
    """
    if not (enabled() and authorized() and mark_watched_enabled()):
        return False
    duration_ms = 0
    try:
        duration_ms = int(float((ctx or {}).get('duration_ms') or 0))
    except Exception:
        duration_ms = 0
    if not force and not should_mark_watched(position_ms, duration_ms):
        return False
    key = _session_key(ctx)
    if key in _MARKED_THIS_SESSION:
        return False
    payload = history_payload(ctx)
    if not payload:
        return False
    try:
        _request('/sync/history', payload=payload, method='POST', auth=True)
        _MARKED_THIS_SESSION.add(key)
        invalidate_cache('/sync/all-items')
        xbmc.log('[DexHub] simkl: marked watched %s' % key, xbmc.LOGINFO)
        return True
    except Exception as exc:
        xbmc.log('[DexHub] simkl mark-watched failed for %s: %s' % (key, exc), xbmc.LOGWARNING)
        return False


# ─── lists ──────────────────────────────────────────────────────────────────

def _node_from_row(row, kind):
    """The item node inside an all-items row: movies→'movie', shows/anime→'show'."""
    if not isinstance(row, dict):
        return {}
    if kind == 'movies':
        return row.get('movie') or {}
    return row.get('show') or {}


def normalize_all_items(data, kind):
    """Normalize a /sync/all-items response into mdblist-shaped rows.

    Output rows: {'_type': 'movie'|'show', 'title', 'year'/'release_year',
                  'overview', 'ids': {'imdb','tmdb','tvdb'}} — the exact shape
    plugin._render_idlist_rows() already consumes for MDBList catalogs.
    """
    rows = []
    if not isinstance(data, dict):
        return rows
    bucket = data.get(kind)
    if bucket is None and kind == 'anime':
        bucket = data.get('anime') or data.get('shows')
    for row in (bucket or []):
        node = _node_from_row(row, kind)
        if not node:
            continue
        ids_in = node.get('ids') or {}
        imdb = str(ids_in.get('imdb') or '').strip()
        tmdb = str(ids_in.get('tmdb') or '').strip()
        tvdb = str(ids_in.get('tvdb') or '').strip()
        if not (imdb or tmdb or tvdb):
            continue  # nothing Dex Hub can route on
        rows.append({
            '_type': 'movie' if kind == 'movies' else 'show',
            'title': node.get('title') or '',
            'year': node.get('year') or '',
            'release_year': node.get('year') or '',
            'overview': node.get('overview') or '',
            'ids': {'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb},
            '_status': str(row.get('status') or ''),
            # v4.2.0: Simkl serves its own poster CDN slug — pass a full URL
            # through so the renderer never shows a bare file icon even when
            # the TMDb art pipeline has nothing for this title.
            'poster': poster_url(node.get('poster')),
            'last_watched': str(row.get('last_watched') or ''),
            'next_to_watch': str(row.get('next_to_watch') or ''),
            'watched_episodes_count': int(row.get('watched_episodes_count') or 0),
            'total_episodes_count': int(row.get('total_episodes_count') or 0),
            'last_watched_at': str(row.get('last_watched_at') or ''),
        })
    return rows


_FAIL_LOG_MEMO = {}


def fetch_all_items(kind='shows', status='watching'):
    """User's Simkl list for one kind/status, normalized (see normalize_all_items)."""
    if not enabled():
        return []
    kind = kind if kind in KINDS else 'shows'
    valid = STATUSES_MOVIES if kind == 'movies' else STATUSES_SHOWS
    status = status if status in valid else valid[0]
    path = '/sync/all-items/%s/%s?extended=full' % (kind, status)
    try:
        data = _cached_request(path, auth=True)
    except Exception as exc:
        # v4.7.5: identical transient network errors (DNS/timeouts) repeated
        # 27 times in one session of the user's log. Report each failure
        # signature at most once an hour; the rest go to DEBUG.
        _sig = '%s|%s|%s' % (kind, status, str(exc)[:60])
        _now = time.time()
        if _now - float(_FAIL_LOG_MEMO.get(_sig) or 0.0) > 3600:
            _FAIL_LOG_MEMO[_sig] = _now
            xbmc.log('[DexHub] simkl fetch_all_items(%s,%s) failed: %s' % (kind, status, exc), xbmc.LOGWARNING)
        else:
            xbmc.log('[DexHub] simkl fetch_all_items(%s,%s) failed (repeat): %s' % (kind, status, exc), xbmc.LOGDEBUG)
        return []
    return normalize_all_items(data, kind)


def import_watched_movies(limit=500):
    """Pull completed movies from Simkl and mark them watched locally.

    v4.1.0 scope: movies only. Per-episode show history needs one request per
    show on Simkl's API; deferred until the batched endpoint is verified live.
    """
    if not (enabled() and authorized()):
        raise RuntimeError(tr('حساب Simkl غير مرتبط'))
    rows = fetch_all_items('movies', 'completed')
    count = 0
    for row in rows[:max(1, int(limit))]:
        ids = row.get('ids') or {}
        imdb = ids.get('imdb') or ''
        tmdb = ids.get('tmdb') or ''
        canonical = imdb if imdb else ('tmdb:%s' % tmdb if tmdb else '')
        if not canonical:
            continue
        try:
            playback_store.mark_watched('movie', canonical, canonical)
            count += 1
        except Exception:
            continue
    return count


# ── v4.2.0: art + full history import + Continue Watching sync ───────────

def poster_url(slug):
    """Simkl poster CDN. [VERIFY-LIVE] `_m` (medium) jpg variant."""
    slug = str(slug or '').strip()
    return ('https://simkl.in/posters/%s_m.jpg' % slug) if slug else ''


_EP_MARKER_RE = re.compile(r's\s*(\d+)\s*e\s*(\d+)', re.I)


def parse_episode_marker(value):
    """'S02E05' / 's2e5' → (2, 5); anything else → None."""
    match = _EP_MARKER_RE.search(str(value or ''))
    if not match:
        return None
    return int(match.group(1)), int(match.group(2))


def _canonical_for(ids):
    imdb = str(ids.get('imdb') or '').strip()
    tmdb = str(ids.get('tmdb') or '').strip()
    tvdb = str(ids.get('tvdb') or '').strip()
    if imdb:
        return imdb if imdb.startswith('tt') else 'tt%s' % imdb
    if tmdb:
        return 'tmdb:%s' % tmdb
    if tvdb:
        return 'tvdb:%s' % tvdb
    return ''


def import_watched(limit=1000):
    """Mark Simkl completed movies + watched show episodes locally.

    Movies: every 'completed' movie → playback_store.mark_watched.
    Shows ('watching' + 'completed' + 'hold'): Simkl's all-items rows carry
    `last_watched` as an SxxEyy marker; episodes 1..Eyy of season Sxx are
    marked. Earlier seasons are intentionally NOT back-filled — real season
    lengths are unknown without one TMDb call per show, and Continue
    Watching correctness comes from sync_continue_watching() pointing at
    `next_to_watch` directly, not from the watched table. Anime rows ride
    the shows pipeline. Returns (movies_marked, episodes_marked).
    """
    if not (enabled() and authorized()):
        raise RuntimeError(tr('حساب Simkl غير مرتبط'))
    from . import playback_store
    movies = 0
    for row in fetch_all_items('movies', 'completed')[:max(1, int(limit))]:
        canonical = _canonical_for(row.get('ids') or {})
        if not canonical:
            continue
        try:
            playback_store.mark_watched('movie', canonical, canonical)
            movies += 1
        except Exception as exc:
            xbmc.log('[DexHub] simkl movie import failed for %s: %s' % (canonical, exc), xbmc.LOGDEBUG)
    episodes = 0
    for kind in ('shows', 'anime'):
        for status in ('watching', 'completed', 'hold'):
            for row in fetch_all_items(kind, status):
                canonical = _canonical_for(row.get('ids') or {})
                marker = parse_episode_marker(row.get('last_watched'))
                if not canonical or not marker:
                    continue
                season, episode = marker
                for e_num in range(1, episode + 1):
                    try:
                        playback_store.mark_watched('series', canonical, '%s:%s:%s' % (canonical, season, e_num))
                        episodes += 1
                    except Exception:
                        pass
    return movies, episodes


def sync_continue_watching(limit=60):
    """Mirror Simkl 'watching' shows into Dex Hub's Continue Watching.

    Simkl has no playback-position API, so each watching show is surfaced as
    a zero-position entry pointing at `next_to_watch` (falling back to the
    episode after `last_watched`). Ordering uses Simkl's last_watched_at so
    imports do not reshuffle the row — same rule as trakt.import_progress.
    """
    if not (enabled() and authorized()):
        return 0
    from . import trakt as _trakt
    from . import playback_store
    pending = []
    for kind in ('shows', 'anime'):
        for row in fetch_all_items(kind, 'watching')[:max(1, int(limit))]:
            ids = row.get('ids') or {}
            canonical = _canonical_for(ids)
            if not canonical:
                continue
            marker = parse_episode_marker(row.get('next_to_watch'))
            if not marker:
                last = parse_episode_marker(row.get('last_watched'))
                marker = (last[0], last[1] + 1) if last else None
            if not marker:
                continue
            season, episode = marker
            ts = _trakt._parse_trakt_ts(row.get('last_watched_at'))
            try:
                art = _trakt._art_bundle_for_ids(
                    {'imdb': ids.get('imdb'), 'tmdb': ids.get('tmdb'), 'tvdb': ids.get('tvdb')},
                    'series', title=row.get('title') or '')
            except Exception:
                art = {'poster': row.get('poster') or '', 'fanart': '', 'clearlogo': ''}
            if not art.get('poster') and row.get('poster'):
                art['poster'] = row.get('poster')
            pending.append({
                'media_type': 'series', 'canonical_id': canonical,
                'video_id': '%s:%s:%s' % (canonical, season, episode),
                'title': row.get('title') or 'Unknown',
                'provider_name': 'Simkl',
                'poster': art.get('poster') or '',
                'background': art.get('fanart') or '',
                'clearlogo': art.get('clearlogo') or '',
                'season': season, 'episode': episode,
                'position': 0.0, 'duration': 0.0, 'percent': 0.0,
                'stream_url': '', 'event_type': 'progress',
                'ext_updated_at': ts,
                'imdb_id': str(ids.get('imdb') or ''),
                'tmdb_id': str(ids.get('tmdb') or ''),
                'show_tmdb_id': str(ids.get('tmdb') or ''),
                'tvdb_id': str(ids.get('tvdb') or ''),
            })
    if not pending:
        return 0
    try:
        return int(playback_store.upsert_entries(pending, mark_dirty=False) or 0)
    except Exception as exc:
        xbmc.log('[DexHub] simkl continue batch sync failed: %s' % exc,
                 xbmc.LOGDEBUG)
        return 0


def watchlist_mirror_rows(limit=200):
    """'Plan to watch' movies+shows shaped for favorites_store mirror rows."""
    if not (enabled() and authorized()):
        return []
    out = []
    for kind, media_type in (('movies', 'movie'), ('shows', 'series'), ('anime', 'series')):
        for row in fetch_all_items(kind, 'plantowatch')[:limit]:
            canonical = _canonical_for(row.get('ids') or {})
            if not canonical:
                continue
            out.append({
                'media_type': media_type,
                'canonical_id': canonical,
                'title': row.get('title') or '',
                'poster': row.get('poster') or '',
                'background': '',
                'clearlogo': '',
                'year': row.get('year') or 0,
                'plot': row.get('overview') or '',
            })
    return out
